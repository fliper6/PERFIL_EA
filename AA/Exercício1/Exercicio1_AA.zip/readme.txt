Membros do grupo:
- Filipa Alves dos Santos (A83631)
- Hugo André Coelho Cardoso (A85006)
- João da Cunha e Costa (A84775)
- Luís Miguel Arieira Ramos (A83930)
- Válter Ferreira Picas Carvalho (A84464)
